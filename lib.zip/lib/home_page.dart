import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = 0;

  // Pages that will show when you click menu items
  final List<Widget> _pages = [
    const Center(child: Text("🏠 Home Page", style: TextStyle(fontSize: 24))),
    const Center(child: Text("❤️ Favorites", style: TextStyle(fontSize: 24))),
    const Center(child: Text("⚙️ Settings", style: TextStyle(fontSize: 24))),
    const Center(child: Text("👤 Profile", style: TextStyle(fontSize: 24))),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Rental Hub "),
        backgroundColor: Colors.brown,
      ),

      // Side Panel (Drawer)
      drawer: Drawer(
        child: Container(
          color: Colors.brown.shade50,
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              const DrawerHeader(
                decoration: BoxDecoration(color: Colors.brown),
                child: Center(
                  child: Text(
                    "Menu",
                    style: TextStyle(color: Colors.white, fontSize: 22),
                  ),
                ),
              ),
              ListTile(
                leading: const Icon(Icons.home, color: Colors.brown),
                title: const Text("Home"),
                onTap: () {
                  setState(() => _selectedIndex = 0);
                  Navigator.pop(context); // close drawer
                },
              ),
              ListTile(
                leading: const Icon(Icons.favorite, color: Colors.red),
                title: const Text("Favorites"),
                onTap: () {
                  setState(() => _selectedIndex = 1);
                  Navigator.pop(context);
                },
              ),
              ListTile(
                leading: const Icon(Icons.settings, color: Colors.grey),
                title: const Text("Settings"),
                onTap: () {
                  setState(() => _selectedIndex = 2);
                  Navigator.pop(context);
                },
              ),
              ListTile(
                leading: const Icon(Icons.person, color: Colors.blue),
                title: const Text("Profile"),
                onTap: () {
                  setState(() => _selectedIndex = 3);
                  Navigator.pop(context);
                },
              ),
            ],
          ),
        ),
      ),

      // Show selected page
      body: _pages[_selectedIndex],
    );
  }
}
